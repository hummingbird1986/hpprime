# App Version
# On the HP Prime, select the Python icon and save it as new python program
# In hp connective kit, right click on new created python program and add new file.
# In main box, input "import filename "
import hpprime as h
import sys
h.eval("PRINT()")

def ip_validation(ip):
    ip_ = ip.split(".")
    if len(ip_) == 4:
        for i in ip_:
            if not i.isdigit() or int(i) > 255 or int(i) < 0:
                return False
        return True
    return False

def cidr_validation(n):
    if not n.isdigit() or not (0 <= int(n) <= 255):
        return False
    inv_n = int(n) ^ 0xFF
    x = inv_n + 1
    return (x & (x - 1)) == 0

def subnet_validation(subnet):
    subnet_ = subnet.split(".")
    if len(subnet_) == 4:
        for i in subnet_:
            if not cidr_validation(i):
                return False
        return True
    return False

def main():
        h.eval("PRINT()")  
        while True:
            _ip = input("Input IP address: ")
            print("\n" + _ip)
            if _ip == "":
                # h.eval("PRINT()")
                sys.exit()
            if ip_validation(_ip):
                break
            print("Input is invalid! Please input again.")

        while True:
            _subnet = input("Input subnet mask address: ")
            print("\n" + _subnet)
            if _ip == "":
                # h.eval("PRINT()")
                sys.exit()
            if subnet_validation(_subnet):
                break
            print("Input is invalid! Please input again.")


        ip_list = _ip.split(".")
        subnet_list = _subnet.split(".")
        network = [str(int(ip_list[i]) & int(subnet_list[i])) for i in range(4)]
        broadcast = [str(int(network[i]) | (int(subnet_list[i]) ^ 0xFF)) for i in range(4)]
        h.eval("PRINT()")
        print("IP Address: ",_ip)
        print("Subnet Mask: ",_subnet)
        print("")
        print("Network Address: " + '.'.join(network))
        print("Broadcast Address: " + '.'.join(broadcast))
  
main()